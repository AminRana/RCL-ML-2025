# Step 1: Importing Libraries
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# Step 2: Defining the Dataset
# X: Years of experience
x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# Y: Salary in thousands
y = [35, 37, 39, 45, 46, 50, 52, 54, 58, 60]

# Step 3: Plotting the Data
plt.scatter(x, y, color='blue')
plt.title("Years of Experience vs Salary")
plt.xlabel("Years of Experience")
plt.ylabel("Salary (in $1000)")
plt.show()

# Step 4: Performing Linear Regression
slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)

# Define the regression line
def linear_regression_line(x):
    return slope * x + intercept

# Apply the function to the dataset
line = list(map(linear_regression_line, x))

# Step 5: Plotting the Regression Line
plt.scatter(x, y, color='blue', label="Data Points")
plt.plot(x, line, color='red', label="Regression Line")
plt.title("Linear Regression: Experience vs Salary")
plt.xlabel("Years of Experience")
plt.ylabel("Salary (in $1000)")
plt.legend()
plt.show()

# Step 6: Evaluating the Model
print(f"Slope: {slope}")
print(f"Intercept: {intercept}")
print(f"R-squared value: {r_value**2}")

# Step 7: Predicting Future Values
years_of_experience = 12
predicted_salary = linear_regression_line(years_of_experience)
print(f"The predicted salary for an employee with {years_of_experience} years of experience is: ${predicted_salary}K")
