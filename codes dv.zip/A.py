import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
import os

# Print the current working directory to verify dataset location
print("Working Directory:", os.getcwd())

# Load the house prices dataset from CSV file
data = pd.read_csv('house_prices_dataset.csv')

# Display the first 20 rows to inspect the dataset's structure and values
print("First 20 rows:")
print(data.head(20))

# Provide dataset information, including data types and non-null counts
print("\nDataset Info:")
print(data.info())

# Show summary statistics (mean, std, min, max, etc.) for numerical columns
print("\nSummary Statistics:")
print(data.describe())

# Visualize the relationship between house size and price using a scatter plot
plt.figure(figsize=(8, 6))
plt.scatter(data['Size'], data['Price'], alpha=0.5, color='blue')
plt.title('Size vs. Price')
plt.xlabel('Size (sq ft)')
plt.ylabel('Price ($)')
plt.savefig('size_vs_price.png')  # Save the plot as an image file
plt.close()  # Close the plot to free memory

# Create a box plot to show price distribution by location
plt.figure(figsize=(8, 6))
sns.boxplot(x='Location', y='Price', data=data, palette='Set2')  # Note: palette is deprecated, consider using hue in future versions
plt.title('Price by Location')
plt.savefig('price_by_location.png')  # Save the plot
plt.close()  # Close the plot

# Generate a histogram to visualize the distribution of bedrooms
plt.figure(figsize=(8, 6))
sns.histplot(data['Bedrooms'], bins=5, color='green')
plt.title('Bedrooms Distribution')
plt.xlabel('Number of Bedrooms')
plt.savefig('bedrooms_hist.png')  # Save the plot
plt.close()  # Close the plot

# Generate a histogram to visualize the distribution of house prices
plt.figure(figsize=(8, 6))
sns.histplot(data['Price'], bins=30, color='purple')
plt.title('Price Distribution')
plt.xlabel('Price ($)')
plt.savefig('price_hist.png')  # Save the plot
plt.close()  # Close the plot

# Prepare features for modeling by selecting relevant columns
X = data[['Size', 'Bedrooms', 'Bathrooms', 'Location']]

# Convert categorical 'Location' column into binary columns using one-hot encoding
X = pd.get_dummies(X, columns=['Location'], drop_first=True)  # drop_first=True to avoid multicollinearity

# Initialize the StandardScaler to normalize numerical features
scaler = StandardScaler()

# Scale numerical features (Size, Bedrooms, Bathrooms) to have mean=0 and variance=1
X[['Size', 'Bedrooms', 'Bathrooms']] = scaler.fit_transform(X[['Size', 'Bedrooms', 'Bathrooms']])