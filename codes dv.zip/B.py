import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the house prices dataset from a CSV file
data = pd.read_csv('house_prices_dataset.csv')

# Prepare feature matrix by selecting relevant columns
X = data[['Size', 'Bedrooms', 'Bathrooms', 'Location']]

# Convert categorical 'Location' column into binary columns using one-hot encoding
X = pd.get_dummies(X, columns=['Location'], drop_first=True)  # drop_first=True to avoid multicollinearity

# Define the target variable (Price)
y = data['Price']

# Initialize StandardScaler and scale numerical features to have mean=0 and variance=1
scaler = StandardScaler()
X[['Size', 'Bedrooms', 'Bathrooms']] = scaler.fit_transform(X[['Size', 'Bedrooms', 'Bathrooms']])

# Split the dataset into training (65%) and testing (35%) sets with a fixed random state for reproducibility
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.35, random_state=42)

# Define a dictionary of models to train and evaluate
models = {
    'Linear Regression': LinearRegression(),
    'Decision Tree': DecisionTreeRegressor(random_state=42),  # Set random state for reproducibility
    'Random Forest': RandomForestRegressor(random_state=42)   # Set random state for reproducibility
}

# Initialize a list to store evaluation results for each model
results = []

# Train each model and evaluate its performance on the test set
for name, model in models.items():
    model.fit(X_train, y_train)  # Train the model on the training data
    y_pred = model.predict(X_test)  # Predict prices for the test set
    mse = mean_squared_error(y_test, y_pred)  # Calculate Mean Squared Error
    rmse = np.sqrt(mse)  # Calculate Root Mean Squared Error
    r2 = r2_score(y_test, y_pred)  # Calculate R-squared score
    results.append([name, f'{mse:.2e}', f'{rmse:.0f}', f'{r2:.2f}'])  # Store results with formatted values

# Generate a scatter plot comparing actual vs. predicted prices for Random Forest model
rf = models['Random Forest']
y_pred_rf = rf.predict(X_test)
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred_rf, alpha=0.5, color='green')  # Plot actual vs. predicted prices
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)  # Add diagonal line for reference
plt.title('Random Forest: Predicted vs. Actual Prices')
plt.xlabel('Actual Price ($)')
plt.ylabel('Predicted Price ($)')
plt.savefig('pred_vs_actual_rf.png')  # Save the plot as an image file
plt.close()  # Close the plot to free memory
# Print the evaluation results for each model
for result in results:
    print(f'{result[0]} - MSE: {result[1]}, RMSE: {result[2]}, R²: {result[3]}')