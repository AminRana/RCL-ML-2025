import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

# Load the house prices dataset from a CSV file
data = pd.read_csv('house_prices_dataset.csv')

# Prepare feature matrix by selecting relevant columns
X = data[['Size', 'Bedrooms', 'Bathrooms', 'Location']]

# Convert categorical 'Location' column into binary columns using one-hot encoding
X = pd.get_dummies(X, columns=['Location'], drop_first=True)  # drop_first=True to avoid multicollinearity

# Define the target variable (Price)
y = data['Price']

# Initialize StandardScaler and scale numerical features to have mean=0 and variance=1
scaler = StandardScaler()
X[['Size', 'Bedrooms', 'Bathrooms']] = scaler.fit_transform(X[['Size', 'Bedrooms', 'Bathrooms']])

# Split the dataset into training (65%) and testing (35%) sets with a fixed random state for reproducibility
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.35, random_state=42)

# Initialize RandomForestRegressor with a fixed random state for reproducibility
rf = RandomForestRegressor(random_state=42)

# Define the parameter grid for hyperparameter tuning
param_grid = {
    'n_estimators': [50, 100, 200],  # Number of trees in the forest
    'max_depth': [None, 10, 20],     # Maximum depth of the trees
    'min_samples_split': [2, 5, 10]  # Minimum number of samples required to split a node
}

# Perform GridSearchCV to find the best hyperparameters using 5-fold cross-validation
grid_search = GridSearchCV(rf, param_grid, cv=5, scoring='neg_mean_squared_error', n_jobs=-1)
grid_search.fit(X_train, y_train)  # Fit the grid search on training data

# Print the best hyperparameters found by GridSearchCV
print(f'Best Parameters: {grid_search.best_params_}')

# Use the best estimator from grid search for evaluation
best_rf = grid_search.best_estimator_
y_pred_tuned = best_rf.predict(X_test)  # Predict prices for the test set with tuned model

# Calculate evaluation metrics for the tuned model
mse_tuned = mean_squared_error(y_test, y_pred_tuned)  # Mean Squared Error
rmse_tuned = np.sqrt(mse_tuned)  # Root Mean Squared Error
r2_tuned = r2_score(y_test, y_pred_tuned)  # R-squared score

# Print the evaluation results for the tuned model
print(f'Tuned - MSE: {mse_tuned:.2e}, RMSE: {rmse_tuned:.0f}, R²: {r2_tuned:.2f}')

# Plot a bar chart comparing RMSE before and after tuning
rmse_default = 23589  # Default RMSE value from Task 2.2 output
plt.figure(figsize=(6, 4))
plt.bar(['Default', 'Tuned'], [rmse_default, rmse_tuned], color=['blue', 'green'])  # Bar plot of RMSE values
plt.title('RMSE Before and After Tuning')
plt.ylabel('RMSE')
plt.savefig('rmse_comparison.png')  # Save the plot as an image file
plt.close()  # Close the plot to free memory